import torch
import torch.nn as nn
import torch.nn.functional as f

class ScaledDotProductAttention(nn.Module):

    ## scaling factor
    def __init__(self, temperature, attn_dropout = 0.1):
        super().__init__()
        self.temperature = temperature
        self.dropout = nn.Dropout(attn_dropout)

    def forward(self, q, k, v, mask = None):

        attn = torch.matmul(q / self.temperature, k.transpose(2, 3))

        if mask is not None:
            attn = attn.masked_fill(mask == 0, -1e9)

        ## obtain weights on the values with softmax
        attn = self.dropout(f.softmax(attn, dim=-1))
        output = torch.matmul(attn, v)

        return output, attn